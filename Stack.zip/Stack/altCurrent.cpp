//http://codeforces.com/contest/343/problem/B
//Alternating Current

#include <iostream>
#include <stack>
using namespace std;

void checkUntangle(string s){
    stack<char> stk;
    
    for(std::string::size_type i=0; i<s.size(); i++)
    {
        if(!stk.empty() && stk.top() == s[i])
            stk.pop();
        else
            stk.push(s[i]);
    }
    
    if(stk.empty())
        cout<<"Yes"<<endl;
    else    
        cout<<"No"<<endl;
}

int main() {
    
    string s;
    
    cin >> s;
    
    checkUntangle(s);
    
	return 0;
}
