//https://www.codechef.com/problems/CKISSHUG
// Use of Expo Mul

#include <iostream>
using namespace std;

typedef long long ll;
#define MOD 1000000007

ll power(int base, int expo){
    ll res = 1;
    
    while(expo > 0){
        if(expo%2 == 1) res = (res*base)%MOD;
        
        res = (base*base)%MOD;
        
        expo/=2;
    }
    
    return res;
}

ll getWays(ll n){
    if(n%2 == 0){
        ll tmp = power(2, n/2);
        return ((2*(tmp-1) + tmp) % MOD);
    }
    else{
        ll tmp = power(2, (n/2)+1);
        return (2*(tmp-1))%MOD;
    }
}

int main() {
    int t;
    cin >> t;
    ll n;
    
    while(t--){
        cin >> n;    
        cout << getWays(n) << endl;
    }
    
	return 0;
}
