//http://codeforces.com/contest/797/problem/C
//minimalString
#include <iostream>
#include <string>
#include <stack>
using namespace std;
 
bool checkMin(char c, int count[]){

    for(int i=0; i<(c - 'a'); i++){
        if(count[i])
            return true;
    }    
    return false;
}


int main() {
    
    string s;
    stack<char> stk;
    int count[26] = {0};
    
    cin >> s;
    
    for(std::string::size_type i=0; i<s.size(); i++)
    {
        count[s[i] - 'a']++;    
    }
        
    for(std::string::size_type i=0; i<s.size(); i++)
    {
        stk.push(s[i]);
        count[stk.top() - 'a']--;
        
        while(!stk.empty() && !checkMin(stk.top(), count))  //Checking for availability of Min Char from TOS
        {
            cout << stk.top();
            stk.pop();
        }
        
        
    }
    
    while(!stk.empty())
    {
        cout << stk.top();
        stk.pop();
    }
    
	return 0;
}