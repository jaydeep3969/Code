//http://codeforces.com/contest/5/problem/C
//Longest Regular Bracket Sequence
#include <iostream>
using namespace std;

void findRegSeq(string s){
    
    int open_count = 0, reg_count=0; //counting opening braces //scaling length of reg_seq
    int count =0, max = -1; //counting total reg_seq //longest seq
    bool extra = false; //checking for extra parenthesis between two reg_seq
    
    for(std::string::size_type i=0; i<s.size(); i++)
    {
        if(s[i] == '('){
            if(reg_count && !open_count && extra){
                count++;
                if(max < (reg_count*2))
                    max = reg_count * 2;
                reg_count = 0;
                extra = false;  
            }
            
            open_count++;
        }
        else{
            if(open_count){
                open_count--;
                reg_count++;
            }
            else if(reg_count){
                extra = true;
            }
        }
    }
    
    if(reg_count){
        count++;
        if(max < (reg_count*2))
            max = reg_count * 2;
    }
    
    if(count)
        cout << max << " " << count << endl;
    else
        cout << "0 1" << endl;
}

int main() {
    
    string s;
    
    cin >> s;
    
    findRegSeq(s);
    
	return 0;
}
